
package beans;
import java.sql.*;

public class DBConnection {
    
    
    
}