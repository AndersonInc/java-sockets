
package beans;
import java.io.Serializable;
public class JavaBeans implements Serializable {
   
    

    public JavaBeans() {
    }
    
    private String fName;
    private String lName;
    private int age;
    private String yearOfWork;
    private String password;
      private String username;
//    public JavaBeans(String fName,String lName,int age,String yearOfWork) {
//        this.fName = fName;
//        this.lName = lName;
//        this.age = age;
//        this.yearOfWork = yearOfWork;
//    }
      
      
      public void setusername(String h){
    this.username = h;
    
    }
      
       public String getusername(){
    return this.username;
    
    }
  public String getfName(){
      return this.fName;
  }
   
    
    public void setfName(String name){
        this.fName = name;
    
}
       public String getlName(){
          return this.lName;
        
    }
    
    public void setlName(String lName){
        this.lName = lName;
    
}
       public int getage(){
           return this.age*age*age;
        
    }
    
    public void setage(int age){
        this.age = age;
    
}
    
       public String getyearOfWork(){
           return this.yearOfWork;
        
    }
    
    public void setyearOfWork(String yearOfWork){
        this.yearOfWork = yearOfWork;
    
}
    
    public void setpassword(String password){
        this.password = password;
        
    }
    public String getpassword(){
        return this.password;
    }
}
