
package beans;

public class Login extends JavaBeans{

    public Login() {
        
    }
 
    private String username;
    private String password;
    
    
   
    public void setusername(String h){
    this.username = h;
    
    }
    
    public void setpassword(String h){
    this.username = h;
    
    }
    
    public String getusername(){
    return this.username;
    
    }
    
     public String getpassword(){
    return this.password;
    
    }
    
}
