
package beans;

import java.io.Serializable;

/**
 *
 * @author victorkakama
 */
public class PasswordReset implements Serializable {
    
    
    private String email;
    private String password;
    private String cpassword;
   
    

    public void setCpassword(String cpassword) {
        this.cpassword = cpassword;
    }
   

    public PasswordReset() {
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getCpassword() {
        return cpassword;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
         
        this.password = password;
        
    }
    
    public String reset(String h, String m){
        if(h==m){
            h=m;
        }
    }
   
    
     
    
}
