import com.sun.xml.internal.ws.handler.ClientLogicalHandlerTube;

import java.net.ServerSocket;
import java.io.IOException;
import java.net.Socket;

public class server {
    private ServerSocket serverSocket;


    public server(ServerSocket serverSocket){this.serverSocket = serverSocket;}
    public void startServer(){
        try{
            while(!serverSocket.isClosed()){
                Socket socket = serverSocket.accept();

                System.out.println(" New client connected to the system!!!");
                ClientHandler clientHandler = new ClientHandler(socket);

                Thread thread = new Thread(clientHandler);
                thread.start();


            }
        }catch (IOException e ){
        e.printStackTrace();

        }
    }
    public static void main(String[] Args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(1234);
         server server = new server(serverSocket);
         server.startServer();
    }
}
